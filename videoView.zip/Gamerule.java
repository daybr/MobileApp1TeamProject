package com.example.team5.shinseoyougi;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class Gamerule extends AppCompatActivity {

    private VideoView mVideoView;
    private String mSdPath = Environment.getExternalStorageDirectory().getAbsolutePath();
    private String mVideoFile = "sin.mp4";
    private String path = mSdPath + "/" + mVideoFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamerule);

        mVideoView = (VideoView) findViewById(R.id.rule);
        MediaController mediaController = new MediaController(Gamerule.this);
        mediaController.setAnchorView(mVideoView);

        Log.d("4csoft", "----     path: " + path);
        if (path == "") {
            Toast.makeText(Gamerule.this, "Please edit VideoView Activity, and set path" + " variable to your media file URL/path", Toast.LENGTH_LONG).show();
        } else {
            mVideoView.setMediaController(mediaController);
            mVideoView.setVideoPath(path);
            mVideoView.requestFocus();
            mVideoView.start();
        }
    }
}
