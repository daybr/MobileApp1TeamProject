package com.example.team5.shinseoyougi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class searchword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        WebView mWebView;
        String googleUrl = "https://www.google.com/ ";
        WebSettings mWebSettings;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchword);

        mWebView = (WebView) findViewById(R.id.webView);
        mWebView.setWebViewClient(new WebViewClient());
        mWebSettings = mWebView.getSettings();
        mWebSettings.setJavaScriptEnabled(true);
        mWebSettings.setBuiltInZoomControls(true);
        mWebSettings.setSupportZoom(true);
        mWebView.loadUrl(googleUrl);

    }
}
